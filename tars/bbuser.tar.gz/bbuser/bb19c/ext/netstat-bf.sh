#!/bin/sh

# $Id: netstat-bf.sh,v 1.5 2003/03/18 16:48:12 cncook Exp $
# netstat-bf.sh
# Craig Cook 13 Aug 2002
# Added osf
# Applied patch from kstailey
# Craig Cook 28 Feb 2003
#   Fixed patch for hpux 10.20
#   Took ideas from James Overbeck
#   - changed "out of order"
#   Added AIX support

MET=netstat
OUT=/tmp/netstat.$$

case $BBOSTYPE in
hpux|aix)
  TMP=/tmp/mynetstat.tmp
  NETSTAT=/usr/bin/netstat
  $NETSTAT -sp tcp > $TMP

  tcpPassiveOpens=`awk '/connections established/ { print $1 }' < $TMP`
  tcpInInorderBytes=`awk '/packets.*bytes.*received in-sequence/ { print substr($3, 2) }' < $TMP`
#  tcpInUnorderBytes=`awk '/out of order packets.*bytes/ { print substr($6, 2) }' < $TMP`
  tcpInUnorderBytes=`awk '/out-of-order packets.*bytes/ { print substr($4, 2) }' < $TMP`
  tcpOutDataBytes=`awk '/data packets.*bytes.$/ { print substr($4, 2) }' < $TMP`
  tcpRetransBytes=`awk '/data packets.*retransmitted$/ { print substr($4, 2) }' < $TMP`
  tcpCurrEstab=`$NETSTAT -n | $GREP ESTABLISHED | $WCC -l`

echo "$BBOSTYPE
udpInDatagrams = 0
udpOutDatagrams = 0
udpInErrors = 0
tcpActiveOpens = 0
tcpPassiveOpens = $tcpPassiveOpens
tcpAttemptFails = 0
tcpEstabResets = 0
tcpCurrEstab = $tcpCurrEstab
tcpOutDataBytes = $tcpOutDataBytes
tcpInInorderBytes = $tcpInInorderBytes
tcpInUnorderBytes = $tcpInUnorderBytes
tcpRetransBytes = $tcpRetransBytes" > $OUT

;;
osf)

  NETSTAT=/usr/sbin/netstat
  echo "$BBOSTYPE" > $OUT
  $NETSTAT -s >> $OUT 
;;

*)
  NETSTAT=/bin/netstat
  echo "$BBOSTYPE" > $OUT
  $NETSTAT -s >> $OUT 
;;

esac

#################
# REPORT
#################
if [ "$LARRDCOMM" = "DATA" ]
then
        $BB $BBDISP "data ${MACHINE}.$MET
`$CAT $OUT`"

else
        $BB $BBDISP "status ${MACHINE}.$MET green `$DATE`  <$MET>
`$CAT $OUT`"

fi

$RM $OUT
