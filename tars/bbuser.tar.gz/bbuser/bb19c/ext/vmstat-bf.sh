#!/bin/sh

# $Id: vmstat-bf.sh,v 1.4 2003/03/18 16:48:12 cncook Exp $
# vmstat-bf.sh

# variable definitions
MET=vmstat
VMSTAT=/usr/bin/vmstat
OUT=$BBTMP/$MET.$$

#################
# COLLECT
#################

# vmstat
echo "$BBOSTYPE" > $OUT
# get the data
$VMSTAT 100 2 | $TAIL -1 >> $OUT

##################
# REPORT
##################

if [ $LARRDCOMM = DATA ]
then
        $BB $BBDISP "data ${MACHINE}.$MET
`$CAT $OUT`"

else
        $BB $BBDISP "status ${MACHINE}.$MET green `$DATE`  <$MET>
`$CAT $OUT`"

fi

$RM $OUT
