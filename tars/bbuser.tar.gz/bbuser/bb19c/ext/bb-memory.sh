#!/bin/sh
# @(#)bb-memory.sh	Bennett Samowich <brs@ben-tech.com>
# External script to check physical and swap memory usage.
#
# 12/21/1999 - Original posting included support for Linux and Solaris.
#                          Todd Jimenez <tjimenez@outpost.com>
# 01/03/2000 - Modified to this format and added AIX and HPUX support.
#                          Bennett Samowich <brs@ben-tech.com>
# 06/16/2003 - Added FreeBSD support.
#                          Mike Hoskins <mike at adept dot org>
# 06/26/2003 - Grep "real mem" and cat cleanup for FreeBSD
#                          Kim Scarborough <sluggo at unknown dot nu>
# 

#
# SCRIPTS IN THE BBHOME/ext DIRECTORY ARE ONLY RUN IF
# LISTED IN THE BBEXT VARIABLE OF $BBHOME/runbb.sh
# THIS IS FOR SECURITY.
#

#
# BBPROG SHOULD JUST CONTAIN THE NAME OF THIS FILE
# USEFUL WHEN YOU GET ENVIRONMENT DUMPS TO LOCATE
# THE OFFENDING SCRIPT...
#
BBPROG=bb-memory.sh; export BBPROG

#
# TEST NAME: THIS WILL BECOME A COLUMN ON THE DISPLAY
# IT SHOULD BE AS SHORT AS POSSIBLE TO SAVE SPACE...
# NOTE YOU CAN ALSO CREATE A HELP FILE FOR YOUR TEST
# WHICH SHOULD BE PUT IN www/help/$TEST.html.  IT WILL
# BE LINKED INTO THE DISPLAY AUTOMATICALLY.
#
TEST="memory"

#
# BBHOME CAN BE SET MANUALLY WHEN TESTING.
# OTHERWISE IT SHOULD BE SET FROM THE BB ENVIRONMENT
#
# BBHOME=/home/sean/bb; export BBHOME   # FOR TESTING
# BBHOME=/usr/local/bb13a; export BBHOME

if test "$BBHOME" = ""
then
        echo "BBHOME is not set... exiting"
        exit 1
fi

if test ! "$BBTMP"                      # GET DEFINITIONS IF NEEDED
then
         # echo "*** LOADING BBDEF ***"
        . $BBHOME/etc/bbdef.sh          # INCLUDE STANDARD DEFINITIONS
fi

#
# NOW COLLECT SOME DATA
# IN THIS CASE, IT'S THE CURRENT MEMORY USAGE OF THE SYSTEM

# SELECT SOME LEVELS... GREEN IS THE DEFAULT...

PERCENT_REAL_WARN="101"         # GO YELLOW AT THIS LEVEL
PERCENT_REAL_PANIC="102"        # GO RED AND PAGE AT THIS LEVEL
PERCENT_SWAP_WARN="80"          # GO YELLOW AT THIS LEVEL
PERCENT_SWAP_PANIC="90"         # GO RED AND PAGE AT THIS LEVEL

# INITIALIZE SOME VALUES
REAL_MEMORY=0
REAL_MEMORY_USED=0
SWAP_MEMORY=0
SWAP_MEMORY_USED=0

case $BBOSTYPE in
	linux | redhat )
		FREE=`/usr/bin/free -m`

                FREE_REAL=`echo "$FREE" | $GREP "Mem"`
                FREE_SWAP=`echo "$FREE" | $GREP "Swap"`

                REAL_MEMORY=`echo $FREE_REAL | $AWK '{ print $2; }'`
                REAL_MEMORY_USED=`echo $FREE_REAL | $AWK '{ print $3; }'`
                SWAP_MEMORY=`echo $FREE_SWAP | $AWK '{ print $2; }'`
                SWAP_MEMORY_USED=`echo $FREE_SWAP | $AWK '{ print $3; }'`
        ;;
	freebsd )
		REAL_MEMORY=`$GREP "real mem" /var/run/dmesg.boot | $TAIL -1 | $AWK '{print $4;}'`
		REAL_MEMORY=`$EXPR $REAL_MEMORY / 1024 / 1024`

		VMSTAT=`/usr/bin/vmstat 1 2 | $TAIL -1`

		REAL_MEMORY_FREE=`echo $VMSTAT | $AWK '{print $5;}'`
		REAL_MEMORY_FREE=`$EXPR $REAL_MEMORY_FREE / 1024`
		REAL_MEMORY_USED=`$EXPR $REAL_MEMORY - $REAL_MEMORY_FREE`

		SWAP=`/usr/sbin/swapinfo -k|$TAIL -1`
		SWAP_MEMORY_USED=`echo $SWAP | $AWK '{print $3;}'`
		SWAP_MEMORY_USED="`$EXPR $SWAP_MEMORY_USED / 1024`"
		SWAP_MEMORY_FREE=`echo $SWAP | $AWK '{print $4;}'`
		SWAP_MEMORY_FREE="`$EXPR $SWAP_MEMORY_FREE / 1024`"
		SWAP_MEMORY="`$EXPR $SWAP_MEMORY_USED + $SWAP_MEMORY_FREE`"
	;;
	solaris )
		PRTCONF=`/etc/prtconf`

		REAL_MEMORY=`echo "$PRTCONF" | $GREP "Mem" | $AWK '{print $3}'`
		
		VMSTAT=`/bin/vmstat 1 2 | $TAIL -1`

		REAL_MEMORY_FREE=`echo $VMSTAT | $AWK '{print $5;}'`
		REAL_MEMORY_FREE=`$EXPR $REAL_MEMORY_FREE / 1024`
		REAL_MEMORY_USED=`$EXPR $REAL_MEMORY - $REAL_MEMORY_FREE`

		SWAP=`/usr/sbin/swap -s`
		SWAP_MEMORY_USED=`echo $SWAP | $AWK '{print $9}' | $SED 's/k//'`
		SWAP_MEMORY_USED="`$EXPR $SWAP_MEMORY_USED / 1024`"

		SWAP_MEMORY_FREE=`echo $SWAP | $AWK '{print $11}' | $SED 's/k//'`
		SWAP_MEMORY_FREE="`$EXPR $SWAP_MEMORY_FREE / 1024`"
		SWAP_MEMORY="`$EXPR $SWAP_MEMORY_USED + $SWAP_MEMORY_FREE`"
	;;
	aix )
		MEMORY=`/usr/local/bin/sudo /usr/sbin/bootinfo -r`
	
		REAL_MEMORY=`$EXPR $MEMORY / 1024`

		VMSTAT=`/usr/bin/vmstat 1 2 | $TAIL -1`

		REAL_MEMORY_FREE=`echo $VMSTAT | $AWK '{print $4;}'`
		REAL_MEMORY_FREE=`$EXPR $REAL_MEMORY_FREE / 256`
		REAL_MEMORY_USED=`$EXPR $REAL_MEMORY - $REAL_MEMORY_FREE`

		SWAP=`/usr/local/bin/sudo /usr/sbin/pstat -s`
		SWAP_MEMORY_USED=`echo $SWAP | $AWK '{print $7}'`
		SWAP_MEMORY_USED=`$EXPR $SWAP_MEMORY_USED / 256`
		SWAP_MEMORY_FREE=`echo $SWAP | $AWK '{print $8}'`
		SWAP_MEMORY_FREE=`$EXPR $SWAP_MEMORY_FREE / 256`
		SWAP_MEMORY=`$EXPR $SWAP_MEMORY_FREE + $SWAP_MEMORY_USED`
	;;
	hpux )
		DMESG=`/sbin/dmesg | $GREP 'Physical.*lockable.*available'`
		REAL_MEMORY=`echo $DMESG | $AWK '{print $2}'`
		REAL_MEMORY=`$EXPR $REAL_MEMORY / 1024`
		
		VMSTAT=`/usr/bin/vmstat 1 2 | $TAIL -1`

		REAL_MEMORY_FREE=`echo $VMSTAT | $AWK '{print $5;}'`
		REAL_MEMORY_FREE=`$EXPR $REAL_MEMORY_FREE / 256`
		REAL_MEMORY_USED=`$EXPR $REAL_MEMORY - $REAL_MEMORY_FREE`

		SWAPINFO=`/usr/sbin/swapinfo -tm | $GREP "total"`
		SWAP_MEMORY=`echo $SWAPINFO | $AWK '{print $2}'`
		SWAP_MEMORY_USED=`echo $SWAPINFO | $AWK '{print $3}'`
		SWAP_MEMORY_FREE=`echo $SWAPINFO | $AWK '{print $3}'`
		;;
	* )
		COLOR="clear"
		STATUS="??? Unknown ???"
		LINE="
Memory routine not defined for this operating system ($BBOSTYPE)"
		$BB $BBDISP "status $MACHINE.$TEST $COLOR `date` - $STATUS $LINE"
		exit 1
	;;
esac

if [ $REAL_MEMORY -eq 0 ]
then
        exit 0
fi

PERCENT_REAL_MEMORY_USED=`$EXPR 100 \* $REAL_MEMORY_USED / $REAL_MEMORY`
PERCENT_SWAP_MEMORY_USED=`$EXPR 100 \* $SWAP_MEMORY_USED / $SWAP_MEMORY`

COLOR="green"
STATUS="Memory OK"

if [ $PERCENT_REAL_MEMORY_USED -ge $PERCENT_REAL_PANIC ]
then
        COLOR="red"
        REAL_COLOR="red"
        STATUS="Memory **very** low"
else
        if [ $PERCENT_REAL_MEMORY_USED -ge $PERCENT_REAL_WARN ]
        then
                REAL_COLOR="yellow"
                if [ "$COLOR" != "red" ]
                then
                        COLOR="yellow"
                        STATUS="Memory low"
                fi
        else
                REAL_COLOR="green"
        fi
fi

LINE="
Memory	  Used	  Total	  Percentage
&${REAL_COLOR} Real	${REAL_MEMORY_USED}M	${REAL_MEMORY}M	${PERCENT_REAL_MEMORY_USED}%"

if [ $PERCENT_SWAP_MEMORY_USED -ge $PERCENT_SWAP_PANIC ]
then
        COLOR="red"
        SWAP_COLOR="red"
        STATUS="Memory **very** low"
else
        if [ $PERCENT_SWAP_MEMORY_USED -ge $PERCENT_SWAP_WARN ]
        then
                SWAP_COLOR="yellow"
                if [ "$COLOR" != "red" ]
                then
                        COLOR="yellow"
                        STATUS="Memory low"
                fi
        else
                SWAP_COLOR="green"
        fi
fi

LINE="$LINE
&${SWAP_COLOR} Swap	${SWAP_MEMORY_USED}M	${SWAP_MEMORY}M	${PERCENT_SWAP_MEMORY_USED}%"

#
# AT THIS POINT WE HAVE OUR RESULTS.  NOW WE HAVE TO SEND IT TO
# THE BBDISPLAY TO BE DISPLAYED...
#
$BB $BBDISP "status $MACHINE.$TEST $COLOR `date` - $STATUS $LINE"
