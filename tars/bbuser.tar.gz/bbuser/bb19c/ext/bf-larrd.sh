#!/bin/sh

# $Id: bf-larrd.sh,v 1.23 2003/03/18 16:54:23 cncook Exp $

# bf-larrd.sh - bottom feeder 
# EXT script for BB that will collect  
# system performance stats to be trended by larrd

################
# DEFINE
################

# LARRDCOMM must be DATA or STATUS  
# use STATUS if you do not have BB compiled for DATAMSG
# this will cause an always green metric column
# we really recommend using the DATA capability of BB
# to avoid BBDISPLAY getting outtahand
LARRDCOMM=STATUS
export LARRDCOMM

# what metrics locally to attempt to gather
# please see the script in bf/ for more detail
# vmstat - output from vmstat
# iostat - solaris >= 2.6 only, disk IO via iostat
# netstat - netstat -s information
# bind - stats bind writes out via syslog
# sendmail - via mailstats
# qmail - qmailanalog or bg
BFMETS="vmstat netstat" 

# put some logic to prevent a meltdown
$GREP "bf-larrd.sh:0" $BBHOME/etc/bb-bbexttab
if [ $? -eq 0 ]
then
	echo 
	echo "bf-larrd.sh not running because it is possible \
	it is not being called properly without :0"
	sleep 300
	exit 1
fi

# work begins here
for met in $BFMETS 
do
	/wic/home/bbuser/bb/ext/$met-bf.sh &
done
