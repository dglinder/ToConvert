#!/bin/sh
#
# bbchkwarnrules.cfg
#
# Version 1.9
# Mar 13th, 2002
#
# (c) Copyright Quest Software, Inc.  1997-2002  All rights reserved.
#
# Check integrity of the bbwarnrules.cfg file
#

if [ ! -r bbwarnrules.cfg ]
then
	echo "Cannot read bbwarnrules.cfg"
	exit 1
fi

rc=0

cat ./bbwarnrules.cfg | grep -v "^#" | \
while read line
do
	set -f		disable globber

	line=`echo $line | sed 's/;;/; ;/g'`
	if [ -z "$line" ]
	then
		continue
	fi


	OLDIFS=$IFS
	IFS=';'
	set $line
	IFS=$OLDIFS

	if [ "$#" -ne 7 ]
	then
		echo "invalid rule: <$line>"
		rc=2
	fi
	
	set +f		#reenable globber
done

exit $rc
